/*
 * Implementation of the Red Pike block cipher algorithm
 */

#include "../../include/number_theory/redpike.hpp"
