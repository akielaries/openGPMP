/*
 * Implementation of a standard or naive neural network
 */
#include "../../include/linalg/matrices.hpp"
#include "../../include/ml/naive_network.hpp"




