/*
 * taking a look at different mathematical operations seen in Linear
 * Algebra in C++
 */
#include <string>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <vector>
#include "../../include/linalg/vectors.hpp"
#include "../../include/linalg/matrix.hpp"


int mtpk::Vectors::add(int a, int b) {
    int c = a + b;
    return c;
}


