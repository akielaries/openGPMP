/*
 * taking a look at different mathematical operations seen in Linear
 * Algebra in C++
 */
#include <string>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <vector>
#include "../../include/linalg/vectors.hpp"
#include "../../include/linalg/matrix.hpp"


int64_t mtpk::Vectors::add(int64_t a, int64_t b) {
    int64_t c = a + b;
    return c;
}


